package edu.uob;

public class Character extends GameEntity{
    public Character(String name, String description) {
        super(name, description);
    }
}
