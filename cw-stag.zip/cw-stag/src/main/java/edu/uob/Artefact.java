package edu.uob;

public class Artefact extends GameEntity{
    public Artefact(String name, String description) {
        super(name, description);
    }
}
