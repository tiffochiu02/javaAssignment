package edu.uob;

import java.util.HashMap;
import java.util.LinkedList;

public class GameCommandsHandling {
    public static Location getCurrentLocation() {
        return GameServer.players.get(0).currentLocation;
    }


    public static String BuiltInCommandHandling(LinkedList<String> tokens) {
        for (String token : tokens) {
            if(token.equalsIgnoreCase("inventory") || token.equalsIgnoreCase("inv")) {
                return GameServer.players.get(0).listArtefacts();
            }
            else if(token.equalsIgnoreCase("get")) {
                return getArtefact(tokens);
            }
            else if(token.equalsIgnoreCase("drop")) {
                return dropArtefact(tokens);
            }
            else if(token.equalsIgnoreCase("goto")) {
                return gotoLocation(tokens);
            }
            else if(token.equalsIgnoreCase("look")) {
                return lookLocation(tokens);
            }
        }
        return "";
    }

    public static String getArtefact(LinkedList<String> tokens) {
        for (String token : tokens) {
            for(int i = 0; i < getCurrentLocation().artefacts.size(); i++) {
                String artefactName = getCurrentLocation().artefacts.get(i).getName();
                if(token.equalsIgnoreCase(artefactName)) {
                    Artefact retrievedArtefact = getCurrentLocation().artefacts.get(i);
                    GameServer.players.get(0).retrieveArtefact(retrievedArtefact);
                    getCurrentLocation().artefacts.remove(i);
                    StringBuilder sMessage = new StringBuilder();
                    return sMessage.append("Added Artefact: ").append(token).append(" to the inventory.").toString();
                }
            }
        }
        StringBuilder fMessage = new StringBuilder();
        return fMessage.append("No artefact ").append(" found.").toString();
    }
    public static String dropArtefact(LinkedList<String> tokens) {
        for (String token : tokens) {
            for(int i = 0; i < GameServer.players.get(0).inventory.size(); i++) {
                String artefactName = GameServer.players.get(0).inventory.get(i).getName();
                if(token.equalsIgnoreCase(artefactName)){
                    Artefact droppedArtefact = GameServer.players.get(0).inventory.get(i);
                    GameServer.players.get(0).removeArtefact(droppedArtefact);
                    getCurrentLocation().artefacts.put(getCurrentLocation().artefacts.size(), droppedArtefact);
                    StringBuilder sMessage = new StringBuilder();
                    return sMessage.append("Dropped Artefact: ").append(token).append(" from the inventory.").toString();
                }
            }
        }
        StringBuilder fMessage = new StringBuilder();
        return fMessage.append("No artefact ").append(" found.").toString();
    }

    public static String gotoLocation(LinkedList<String> tokens) {
        String newLocationName = "";
        for (String token : tokens) {
           int numOfPaths = getCurrentLocation().paths.size();
           for(int i = 0; i < numOfPaths; i++) {
               if(token.equalsIgnoreCase(getCurrentLocation().paths.get(i))) {
                   newLocationName = getCurrentLocation().paths.get(i);
               }
           }
        }
        for(int i = 0; i < GameServer.newEntities.locations.size(); i++) {
            if(newLocationName.equalsIgnoreCase(GameServer.newEntities.locations.get(i).getName())) {
                GameServer.players.get(0).setLocation(GameServer.newEntities.locations.get(i));
                StringBuilder sMessage = new StringBuilder();
                return sMessage.append("Arrived at location: ").append(newLocationName).append(".").toString();
            }
        }
        StringBuilder fMessage = new StringBuilder();
        return fMessage.append("No location ").append(" found.").toString();
    }

    //look prints details of the current location (including all entities present) and lists the paths to other locations
    public static String lookLocation(LinkedList<String> tokens) {
        String currentLocationName = getCurrentLocation().name;
        String currentLocationDescription = getCurrentLocation().description;
        String allArtefacts = getCurrentLocation().listAllArtefacts();
        String allFurniture = getCurrentLocation().listAllFurniture();
        String allPaths = getCurrentLocation().getPaths().toString();
        StringBuilder sb = new StringBuilder();
        sb.append("You are at ").append(currentLocationName).append(": ").append(currentLocationDescription).append("\n");
        sb.append("Artefacts: ").append(allArtefacts).append("\n");
        sb.append("Furniture: ").append(allFurniture).append("\n");
        sb.append("Paths: ").append(allPaths).append("\n");
        return sb.toString();
    }

    public String customCommandHandling(LinkedList<String> tokens) {
        setCurrentAction(tokens);
        if(GameServer.players.get(0).getCurrentAction() == null){
            return "The action is not valid.";
        }
        consumedEntity();

    }

    public String consumedEntity(){
        GameAction currentAction = GameServer.players.get(0).getCurrentAction();
        Location storeroom = new Location("","");
        for(Integer key: GameServer.newEntities.locations.keySet()){
            storeroom = GameServer.newEntities.locations.get(key);
        }
        for(Integer key: currentAction.consumed.keySet()) {
            String consumed = currentAction.consumed.get(key);
            Artefact consumedInvArtefact = consumeInventory(consumed);
            Artefact consumedArtefact = consumeArtefact(consumed);
            Furniture consumedFurniture = consumeFurniture(consumed);
            Character consumedCharacter = consumeCharacter(consumed);

            if(consumedArtefact != null) {
                storeroom.addArtefact(consumedArtefact);
                return "Consumed "
            } else if(consumedFurniture != null) {
                storeroom.addFurniture(consumedFurniture);
            } else if(consumedCharacter != null) {
                storeroom.addCharacter(consumedCharacter);
            } else if(consumedInvArtefact != null) {
                storeroom.addArtefact(consumedInvArtefact);
            }
        }

    }
    public Artefact consumeInventory(String consumed){
        for(Integer subKey: GameServer.players.get(0).inventory.keySet()){
            String assetName = GameServer.players.get(0).inventory.get(subKey).getName();
            String assetDescription = GameServer.players.get(0).inventory.get(subKey).getDescription();
            if(consumed.equalsIgnoreCase(assetName)){
                GameServer.players.get(0).inventory.remove(subKey);
                return new Artefact(assetName, assetDescription);
            }
        }
        return null;
    }
    public Artefact consumeArtefact(String consumed){
        for(Integer subKey: getCurrentLocation().artefacts.keySet()){
            String artefactName = getCurrentLocation().artefacts.get(subKey).getName();
            String artefactDescription = getCurrentLocation().artefacts.get(subKey).getDescription();
            if(consumed.equalsIgnoreCase(artefactName)){
                getCurrentLocation().artefacts.remove(subKey);
                return new Artefact(artefactName, artefactDescription);
            }
        }
        return null;
    }
    public Furniture consumeFurniture(String consumed){
        for(Integer subKey: getCurrentLocation().furniture.keySet()){
            String furnitureName = getCurrentLocation().furniture.get(subKey).getName();
            String furnitureDescription = getCurrentLocation().furniture.get(subKey).getDescription();
            if(consumed.equalsIgnoreCase(furnitureName)){
                getCurrentLocation().furniture.remove(subKey);
                return new Furniture(furnitureName, furnitureDescription);
            }
        }
        return null;
    }
    public Character consumeCharacter(String consumed){
        for(Integer subKey: getCurrentLocation().characters.keySet()){
            String characterName = getCurrentLocation().characters.get(subKey).getName();
            String characterDescription = getCurrentLocation().characters.get(subKey).getDescription();
            if(consumed.equalsIgnoreCase(characterName)){
                getCurrentLocation().characters.remove(subKey);
                return new Character(characterName, characterDescription);
            }
        }
        return null;
    }

    //Note that the action is only valid if ALL subject entities (as specified in the actions file)
    // are available to the player. If a valid action is found,
    // your server must undertake the relevant additions/removals (production/consumption).
    public static void setCurrentAction(LinkedList<String> tokens) {
        boolean triggerMatched = false;
        boolean allSubjectMatched = false;
        GameAction currentAction = new GameAction();
        for(int i = 0; i < GameServer.newActions.actions.size(); i++) {
            currentAction = GameServer.newActions.actions.get(i);
            for(int j = 0; j < currentAction.getTriggers().size(); j++){
                for (String token : tokens) {
                    if(token.equalsIgnoreCase(currentAction.getTriggers().get(j))) {
                       triggerMatched = true;
                    }
                }
            }
            //check if location entities match with the subjects of this current action
            for(int m = 0; m < currentAction.getSubjects().size(); m++) {
                String subjectName = currentAction.subjects.get(m);
                boolean subjectMatched = false;
                for(int k = 0; k < getCurrentLocation().artefacts.size(); k++) {
                    String artefactName = getCurrentLocation().artefacts.get(k).getName();
                    if(subjectName.equalsIgnoreCase(artefactName)) {
                        subjectMatched = true;
                    }
                }
                for(int k = 0; k < getCurrentLocation().furniture.size(); k++) {
                    String furnitureName = getCurrentLocation().furniture.get(k).getName();
                    if(subjectName.equalsIgnoreCase(furnitureName)) {
                        subjectMatched = true;
                    }
                }
                for(int k = 0; k < GameServer.players.get(0).inventory.size(); k++) {
                    String assetName = GameServer.players.get(0).inventory.get(k).getName();
                    if(subjectName.equalsIgnoreCase(assetName)) {
                        subjectMatched = true;
                    }
                }
                for(int k = 0; k < getCurrentLocation().characters.size(); k++) {
                    String characterName = getCurrentLocation().characters.get(k).getName();
                    if(subjectName.equalsIgnoreCase(characterName)) {
                        subjectMatched = true;
                    }
                }if(!subjectMatched){return; }
                allSubjectMatched = true;
            }
        }
        if(triggerMatched && allSubjectMatched) {
           GameServer.players.get(0).setCurrentAction(currentAction);
        }
    }
}


